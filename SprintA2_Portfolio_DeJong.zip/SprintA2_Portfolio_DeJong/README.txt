This program is a simple to-do list that can have list items added to it or removed from it.

Setup:
 - Setup is incredibly simple so long as the main HTML file, CSS file, and JavaScript (.js) file are all stored within the same folder.

 For Devs:
 - Are you f***ing kidding me? Seriously, any developer who wants to add-on to this program could build a much better to-do list.
   This was thrown together over the course of an hour. Seriously guys, just... Just build your own.